#!/usr/bin/env bash

# Script by zumbiepig

# check dependencies
for dep in java tmux caddy; do
	if ! command -v "$dep" >/dev/null; then
		echo "$dep is not installed."
		exit 1
	fi
done

# check if jar was downloaded
if [ ! -f server/server.jar ]; then
	echo "Please download paper from https://papermc.io/downloads/paper, name it server.jar, and place it in the server/ folder"
	exit 1
fi
if [ ! -f bungee/bungee.jar ]; then
	echo "Please download bungee from https://www.spigotmc.org/go/bungeecord-dl, name it bungee.jar, and place it in the bungee/ folder"
	exit 1
fi

# change Xmx and Xms values to adjust ram
SERVER_OPTS='-Xmx6G -Xms6G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:+AlwaysPreTouch -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1 -Dusing.aikars.flags=https://mcflags.emc.gs -Daikars.new.flags=true'
BUNGEE_OPTS='-Xmx128M -Xms128M -XX:+UseG1GC -XX:G1HeapRegionSize=4M -XX:+UnlockExperimentalVMOptions -XX:+ParallelRefProcEnabled -XX:+AlwaysPreTouch'

sudo caddy stop &>/dev/null # if caddy service is running on startup
tmux new -d -s eagler_caddy "caddy run"
tmux new -d -s eagler_bungee "cd bungee && java ${BUNGEE_OPTS} -jar bungee.jar"
tmux new -d -s eagler_server "cd server && java ${SERVER_OPTS} -jar server.jar nogui; tmux kill-session -t eagler_bungee; caddy stop"
echo "Make sure to open port 443 in your firewall!"
echo "Run 'tmux attach -t eagler_server' to reattach"
tmux attach -t eagler_server
